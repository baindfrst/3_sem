
        string sucs;